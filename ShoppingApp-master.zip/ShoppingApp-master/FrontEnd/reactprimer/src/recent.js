import React from 'react'
import axios from 'axios'
import ReactDOM from "react-dom";
import Store from './store'
import Cart from './cart'
import Scrollbar from 'react-scrollbars-custom'


class Recent extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            recentItems: ''
        }
    }
    async componentDidMount(){
        this.showRecentItems()
    }

    async showRecentItems(){
        const token = this.props.jwt
        const response = await axios.get('http://localhost:8080/StoreItem/Recent',{ 'headers': {'Authorization' : 'Bearer ' + token }})
        const recentArr = response.data
        this.setState({recentItems:recentArr})
        this.state.recentItems.array.forEach(element => {   
            console.log(element)
        });
    }



    render(){
        return( <div> 
            
            <br></br>
            <Scrollbar id = "recentScroll" style = {{width: 450, height: 250}}>
            <ul>{}
            </ul>
            </Scrollbar>
            
         
        </div>

        )
    }
        
    

}

export default Store