import React from 'react';
import Greetings from "./greetings"
import axios from 'axios'
import {Button, Accordion, Card} from 'react-bootstrap'

export default class GreetingsContainer extends React.Component {
    constructor(props) {
        super(props); 
        //new containing class that has its own state
        this.state = {
            greetingsContainerState: false,
            users: [
              {
                firstName: "Carla",
                lastName: "zac"
              }
            ]
    }  
    this.toggleGreetingState = this.toggleGreetingState.bind(this)
    }

     async componentDidMount(){
       await this.loadUsersFromRESTAPI()
       this.setState({greetingsContainerState:true})

     }
        
      async loadUsersFromRESTAPI(){
        const userResponse = await axios.get('http://localhost:8080/user')
        const users = userResponse.data;
        users.forEach(user => {
            this.setState({users: this.state.users.concat(
                {firstName: user.firstName, lastName: user.lastName})
            })
        });
        /*axios.get('http://localhost:3200/user').then(res => 
        {
            console.log(res.data)
            this.setState({data: Object.values(res.data)})
            console.log(this.state)
        }).catch(err => console.log(err));*/
    }

    toggleGreetingState(){
        this.setState({greetingsContainerState: !this.state.greetingsContainerState})
    }

    render(){
        return(
        <div>
          <Greetings user = {this.state.users[0]}
              toggleHandler = {this.toggleGreetingState}
              greetingsContainerState = {this.state.greetingsContainerState}/>
            
            
        </div>)
    }
}