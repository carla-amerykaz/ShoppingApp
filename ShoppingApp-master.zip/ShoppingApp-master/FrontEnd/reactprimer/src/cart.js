import React from 'react'
import axios from 'axios'
import ReactDOM from "react-dom";
import Scrollbar from 'react-scrollbars-custom'

class Cart extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            cart: '',
            removeNameArr: []
        }

    }

    async componentDidMount(){
         this.loadCartItemsFromRESTAPI()
    }

    showCartItems(){
        return this.state.cart
    }

   async removeFromCart(){
       let name = this.state.removeNameArr[0]
        //await this.loadCartItemsFromRESTAPI()
        const filterArr = this.state.cart.filter(function(value, index, arr){
            return value == name
        })
        this.addToStateArr(filterArr)
        this.setState({cart: filterArr})
        //ReactDOM.render(<ul>{this.state.cart}</ul>, document.getElementById("cartUl"))

    }

     addToStateArr(arr){
         console.log(arr)
        let listArr = []
        arr.forEach(item => {
            console.log(item)
        listArr.push(<div id="removeDiv">
            <li>Quantity: {item.quantity} Name: {item.storeItem.name}
                     In Store Qty: {item.storeItem.quantity} </li> 
         <button id= "removeBtn"  onClick = {() => {
             let array = this.state.removeNameArr
             array.push(item.storeItem.name)
             this.setState({removeNameArr: array})
             this.removeFromCart()
         }}> Remove From Cart </button>
            </div>)
    })
    this.setState({cart:listArr})

    }

    async loadCartItemsFromRESTAPI(){
        const userJwt = this.props.jwt
        const userID = this.props.user
          const headers = {
              'Authorization': `Bearer: ${this.props.jwt}`
          }
        const userResponse = await axios.get(`http://localhost:8080/user/${this.props.user}/cart`, {headers})
        const data = userResponse.data
        const cartItems = data.cartItems
        cartItems.forEach(item => {
            console.log(item)
        })
        this.addToStateArr(cartItems)
        //ReactDOM.render(<ul>{this.state.cart}</ul>, document.getElementById("cart"))
    }

    showCartItems(){
        return this.state.cart
    }

    render(){

        return(
            <div>
                <Scrollbar id= "cart" style = {{width: 450, height: 250}}> 
                <ul id = "cartUl">
                    {this.state.cart}
                </ul>
                </Scrollbar>
            </div>

        )
    
}
}

export default Cart;