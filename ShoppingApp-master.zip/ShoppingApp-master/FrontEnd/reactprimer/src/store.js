import React from 'react'
import axios from 'axios'
import ReactDOM from "react-dom";
import Scrollbar from 'react-scrollbars-custom'


class Store extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            storeItems: '',
            search: '',
            searchItems: '',

        }
        this.searchInputHandler = this.searchInputHandler.bind(this)
        this.searchBtnHandler = this.searchBtnHandler.bind(this)

    }

    async componentDidMount(){
        this.loadStoreItemsFromRESTAPI()
    }

    async loadStoreItemsFromRESTAPI(){
        const token = this.props.jwt
        const storeResponse = await axios.get('http://localhost:8080/Store', { 'headers': {'Authorization' : 'Bearer ' + token }})
        const items = storeResponse.data;
        const listArray =[]
        items.forEach(item => {
        listArray.push(
            <div>
             <li>Name: {item.name} Qty: {item.quantity}</li>
            <button> Add to cart</button>
            <button>View Item</button>
            </div>
        )})
        this.setState({storeItems:listArray})
    }

    showItems(){
        return this.state.storeItems
    }

    searchInputHandler(event){
        this.setState({search: event.target.value})
    }

    async searchBtnHandler(){
        const token = this.props.jwt
        let config = {
            withCredentials: true,
            headers: {'Authorization': 'Bearer ' + token},
            params: {
              description: this.state.search,
              name: this.state.search
            },
          }
        const response = await axios.get('http://localhost:8080/StoreItem', config)
        const searchItems = response.data
        const searchItemArr = []
        searchItems.forEach(searchItem => {
        searchItemArr.push(<li> Name: {searchItem.name} Descr: {searchItem.description}</li>)
        })
        this.setState({searchItems: searchItemArr})
       // ReactDOM.render(<div>{response.data.description}</div>, document.getElementById("scrollStore"))
    ReactDOM.render(this.state.searchItems, document.getElementById("storeScroll"))
    }

    showSearchItems(){
        return this.state.searchItems
    }

    render(){
        return( 
            <div> 
                <div>
                <br></br>
                 <input placeholder= "Search" onBlur ={this.searchInputHandler}/> 
                 <button onClick = {this.searchBtnHandler}>Search</button>
                <Scrollbar id = "storeScroll" style = {{width: 450, height: 250}}>
                <ul>{this.showItems()}
                </ul>
                </Scrollbar>
                </div>
             
            </div>
            
        )
    }
}

export default Store