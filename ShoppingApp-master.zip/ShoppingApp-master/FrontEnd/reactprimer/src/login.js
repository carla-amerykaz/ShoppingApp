import React from 'react'
import axios from 'axios'
import ReactDOM from "react-dom";
import Store from './store'
import Cart from './cart'
import Scrollbar from 'react-scrollbars-custom'
import Recent from './recent'

class Login extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            firstName: '',
            lastName: '',
            login:'',
            password: '',
            jwt: '',
            userID:'',
            cartID: ''
        }
        this.loginEventHandler = this.loginEventHandler.bind(this);
        this.loginInputHandler =this.loginInputHandler.bind(this);
        this.passwordInputHandler =this.passwordInputHandler.bind(this);
        this.storeItemsEventHandler = this.storeItemsEventHandler.bind(this)
        this.cartEventHandler = this.cartEventHandler.bind(this)
        this.recentlyViewedHandler = this.recentlyViewedHandler.bind(this)
        axios.defaults.withCredentials = true;
        axios.defaults.headers.common = {'Authorization': `Bearer ${this.state.jwt}`}
    }

    async loginEventHandler(){
        const loginBody = {login: this.state.login, password: this.state.password}
       const response = await axios.post('http://localhost:8080/user/login', loginBody)
       console.log(response)
       this.setState({firstName: response.data.user.firstName, lastName: response.data.user.lastName,
        jwt: response.data.accessToken, userID: response.data.user._id, cartID: response.data.user.cart._id})

       ReactDOM.render(
        <div>
            <h1 id = "greet ">HELLO {this.state.firstName} {this.state.lastName}</h1>
        </div>, 
       document.getElementById("changeLogin"));
        this.showOptions();
    }

    loginInputHandler(event){
        this.setState({login: event.target.value})
    }

    passwordInputHandler(event){
        this.setState({password: event.target.value})
    }

    showOptions(){
        ReactDOM.render(<div>
                    <button id="btnStoreItems" onClick ={this.storeItemsEventHandler} >Store Items</button>
                    <button onClick = {this.cartEventHandler}>Cart</button>
                    <button onClick = {this.recentlyViewedHandler}>Recently Viewed</button>
                    <div id = "mainSection">
                        <div id="cartScroll">
                        </div>
                        <div id = "storeScroll">
                        </div>
                        <div id="recentlyViewedScroll">
                        </div>
                    </div>
                    </div>,
             document.getElementById("mainBts"));
        
    }

    storeItemsEventHandler(){
        ReactDOM.render(<div><h2>Store</h2><Store jwt = {this.state.jwt}/>
                </div>, document.getElementById("storeScroll"))

    }

    cartEventHandler(){
        ReactDOM.render(<div><h2> Cart</h2><Cart recentlyViewed = {this.recentlyViewedHandler} jwt = {this.state.jwt} user = {this.state.userID} /></div>, document.getElementById("cartScroll"))

    }

    recentlyViewedHandler(){
        ReactDOM.render(<div>
            <Recent jwt = {this.state.jwt}> </Recent>
            </div>
        , document.getElementById("recentlyViewedScroll"))
        

    }


    render(){
        return(
            <div>
                <div id = "changeLogin">
                <input placeholder= "Login" onBlur ={this.loginInputHandler}/> 
                <input type="password" placeholder="Password" onBlur = {this.passwordInputHandler}/> 
                <button onClick = {this.loginEventHandler}> Login!</button>
                </div>
                <div id = "mainBts"></div>
            </div>
            
           
        )
    }

}

export default Login