import logo from './logo.svg';
import './App.css';
import React from 'react'
import GreetingsContainer from "./greetingsContainer"
import Login from "./login"
import {  Nav, Navbar } from 'react-bootstrap';
import axios from 'axios';


function App() {

    return (
       <div className = "App"> 
    <div id = "loginHeader">
    <br></br>
    <Login/>

    </div>
    
    <GreetingsContainer/>
    </div>)
  }

     
export default App;