import React from 'react';

export default class Greetings extends React.Component {
        constructor(props) {
            super(props);
        }

    showGreeting(){
            if (this.props.greetingsContainerState){
                return (<span> {this.props.user.firstName} {this.props.user.lastName}</span>)
            }
        }
        render() {
        return (
        <div>
            
            
        </div>
         )
           
    }

}


